<?php
/**
 * Header. Elementor Pro Theme Builder header wins; otherwise the saved Elementor
 * header template; otherwise the PHP fallback (identical markup to the design).
 *
 * @package BrickPoint
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="bp-site">
<a class="screen-reader-text skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'brickpoint' ); ?></a>
<?php
if ( ! bp_elementor_header() ) {
	get_template_part( 'template-parts/header/site-header' );
}
?>
<main id="main" class="bp-main">
