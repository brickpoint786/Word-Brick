<?php
/**
 * bp_product archive (delegates to archive.php).
 *
 * @package BrickPoint
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
include get_template_directory() . '/archive.php';
